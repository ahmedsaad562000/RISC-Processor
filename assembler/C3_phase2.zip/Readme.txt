Assembler Manual

1- Run Assembler.exe
	---if it didn't open for any reason please try to open Assemble.bat and check you have python installed on your device 
	
2- Enter The path of the input file and its extension 
	--(ex "t2.txt" without the quotes)
	
3- Enter The path of the output file (whether it exists or will be created) and its extension (ex results_1.mem)

4- Thank You

	